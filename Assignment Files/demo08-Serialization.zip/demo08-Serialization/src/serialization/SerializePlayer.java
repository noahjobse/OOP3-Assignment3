package serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import domain.*;

/**
 * Created on Nov 3, 2024
 *
 * Project: demo08-Serialization
 *
 * @author kitty
 * @version 1.2
 * 
 */

public class SerializePlayer
{
	static ArrayList<Player> players = new ArrayList<>();
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// make some players to play with, pun intended
		players.add( new Warrior( "Kitty" ) );
		players.add( new Ranger( "Nick" ) );
		
		System.out.println( "List before serialization:\n" + players );
		serializePlayersToFile();
		deserializePlayersFromFile();
		System.out.println( "\nList after serialization:\n" + players );
	}
	
	public static void serializePlayersToFile()
	{
		try
		{
			ObjectOutputStream oos = new ObjectOutputStream(
					new FileOutputStream("res/players.ser"));
			
			for(int i = 0; i < players.size(); i++)
			{
				oos.writeObject(players);
			}
			oos.close();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings( "unchecked" )
	public static void deserializePlayersFromFile()
	{
		try
		{
			ObjectInputStream ois = new ObjectInputStream(
						new FileInputStream("res/players.ser"));
			
			players = (ArrayList<Player>) ois.readObject();
			ois.close();
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}
}
