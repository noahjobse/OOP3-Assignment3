package domain;

import java.io.Serializable;

/**
 * Created on Nov 3, 2024
 *
 * Project: demo08-Serialization
 *
 * @author kitty
 * @version 1.2
 * 
 */

public class Item implements Serializable
{
	/**
	 *  auto-generated serial ID
	 */
	private static final long serialVersionUID = -2260771414387671456L;
	private String name;
	private int amount;
	
	public Item( String name, int amount )
	{
		this.name = name;
		this.amount = amount;
	}
	
	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName( String name )
	{
		this.name = name;
	}
	/**
	 * @return the amount
	 */
	public int getAmount()
	{
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount( int amount )
	{
		this.amount = amount;
	}
	
	public String toString()
	{
		return this.name + " - amount: " + this.amount;
	}
	
}
