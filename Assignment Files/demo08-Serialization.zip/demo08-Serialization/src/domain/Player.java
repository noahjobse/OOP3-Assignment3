package domain;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created on Nov 3, 2024
 *
 * Project: demo08-Serialization
 *
 * @author kitty
 * @version 1.2
 * 
 */

public abstract class Player implements Serializable
{
	/**
	 *  auto-generated serial ID
	 */
	private static final long serialVersionUID = -9144072284357672833L;
	
	private String name;
	private int level;
	private ArrayList<Item> items;
	private ArrayList<Weapon> weapons;
	
	public Player( String name )
	{
		this.name = name;
		this.level = 1;
		this.items = new ArrayList<>();
		items.add( new Item( "Coins", 100 ) );
		items.add( new Item( "Potion", 5 ) );
		this.weapons = new ArrayList<>();
	}
	
	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName( String name )
	{
		this.name = name;
	}
	/**
	 * @return the level
	 */
	public int getLevel()
	{
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel( int level )
	{
		this.level = level;
	}
	/**
	 * @return the items
	 */
	public ArrayList<Item> getItems()
	{
		return items;
	}
	/**
	 * @param items the items to set
	 */
	public void setItems( ArrayList<Item> items )
	{
		this.items = items;
	}
	/**
	 * @return the weapons
	 */
	public ArrayList<Weapon> getWeapons()
	{
		return weapons;
	}
	/**
	 * @param weapons the weapons to set
	 */
	public void setWeapons( ArrayList<Weapon> weapons )
	{
		this.weapons = weapons;
	}	
	
	public void addWeapon(Weapon newWeapon )
	{
		this.weapons.add( newWeapon );
	}
	
	public String toString()
	{
		return this.name + " - level: " + this.level + "\nWeapons: " + this.weapons 
				+ "\nItems: " + this.items + "\n";
	}
	
}
