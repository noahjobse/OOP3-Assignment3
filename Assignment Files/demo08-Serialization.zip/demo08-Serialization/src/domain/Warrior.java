package domain;

import java.io.Serializable;

/**
 * Created on Nov 3, 2024
 *
 * Project: demo08-Serialization
 *
 * @author kitty
 * @version 1.2
 * 
 */

public class Warrior extends Player implements Serializable
{

	/**
	 *  auto-generated serial ID
	 */
	private static final long serialVersionUID = 7310579293427563209L;

	public Warrior( String name )
	{
		super( name );
		this.addWeapon( new Weapon( "Sword", 1 ) );
	}

}
