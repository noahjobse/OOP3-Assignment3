package domain;

import java.io.Serializable;

/**
 * Created on Nov 3, 2024
 *
 * Project: demo08-Serialization
 *
 * @author kitty
 * @version 1.2
 * 
 */

public class Weapon implements Serializable
{
	/**
	 *  auto-generated serial ID
	 */
	private static final long serialVersionUID = -7439755294140817962L;
	private String name;
	private int level;
	
	public Weapon( String name, int level )
	{
		this.name = name;
		this.level = level;
	}
	
	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName( String name )
	{
		this.name = name;
	}
	/**
	 * @return the level
	 */
	public int getLevel()
	{
		return level;
	}
	/**
	 * @param level the level to set
	 */
	public void setLevel( int level )
	{
		this.level = level;
	}

	public String toString()
	{
		return this.name + " - level: " + this.level;
	}
}
