package domain;

import java.io.Serializable;

/**
 * Created on Nov 3, 2024
 *
 * Project: demo08-Serialization
 *
 * @author kitty
 * @version 1.2
 * 
 */

public class Ranger extends Player implements Serializable
{

	/**
	 *  auto-generated serial ID
	 */
	private static final long serialVersionUID = 5479126925293071019L;

	public Ranger( String name )
	{
		super( name );
		this.addWeapon( new Weapon( "Bow", 1 ) );
	}

}
