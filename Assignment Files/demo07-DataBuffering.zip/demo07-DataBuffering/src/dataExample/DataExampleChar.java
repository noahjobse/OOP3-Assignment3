/**
 * Created on Nov 3, 2024
 *
 * Project: demo07-DataBuffering
 */

package dataExample;

import java.io.*;

/**
 * Data Buffering with Character Streams
 *
 * @author kitty
 * @version 1.1
 * 
 */

public class DataExampleChar
{
	//Constants
	private static final int N = 10000;
	
	//Attributes
	private static long	unBufferedWriteTime,
						unBufferedReadTime,
						bufferedWriteTime,
						bufferedReadTime;
	
	/**
	 * method to save values to file without buffering
	 */
	public static void generateRandomNumberFileUnBuffered()
	{
		long start,stop;
		start = System.nanoTime();
		try
		{
			PrintWriter out = new PrintWriter(
					new File("res/noBuffer.txt"));
			
			for(int i = 0; i < N; i++)
			{
				int number = (int)(Math.random() * 255);
				out.print(number);
//				System.out.println(i+" = "+number);
			}
			out.close();
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop = System.nanoTime();
		unBufferedWriteTime = stop - start;
		
	}
	
	/**
	 * method to retrieve values from file without buffering
	 */
	public static void readIntegerFileInUnBuffered()
	{
		long start,stop;
		start = System.nanoTime();
		try
		{
			FileReader in = new FileReader(
					new File("res/noBuffer.txt"));
			
			for(int i = 0; i < N; i++)
			{
				int value = in.read();
//				System.out.println(i+" = "+value);
			}
			in.close();
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch( IOException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop = System.nanoTime();
		unBufferedReadTime = stop - start;
	}
	
	/**
	 * method to save values to file with buffers
	 */
	public static void generateRandomNumberFileBuffered()
	{
		long start,stop;
		start = System.nanoTime();
		try
		{
			BufferedWriter out = new BufferedWriter(
					new PrintWriter(
					new File("res/buffered.txt")));
			
			for(int i = 0; i < N; i++)
			{
				int number = (int)(Math.random() * 255);
				out.write( number );
//				System.out.println(i+" = "+number);
			}
			out.close();
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop = System.nanoTime();
		bufferedWriteTime = stop - start;
	}
	
	/**
	 * method to retrieve values from file with buffers
	 */
	public static void readIntegerFileInBuffered()
	{
		long start,stop;
		start = System.nanoTime();
		try
		{
			BufferedReader in = new BufferedReader(
					new FileReader(
					new File("res/buffered.txt")));
			
			for(int i = 0; i < N; i++)
			{
				int value = in.read();
//				System.out.println(i+" = "+value);
			}
			in.close();
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		stop = System.nanoTime();
		bufferedReadTime = stop - start;
	}
	
	/**
	 * method to display benchmarking
	 */
	public static void printRunTimes()
	{
		System.out.println("Total time for unbuffered output = "+
							unBufferedWriteTime);
		System.out.println("Total time for unbuffered input = "+
							unBufferedReadTime);
		System.out.println("Total time for buffered output = "+
							bufferedWriteTime);
		System.out.println("Total time for buffered input = "+
							bufferedReadTime);
	}

	/**
	 * testing out buffering results
	 */
	public static void main(String[] args)
	{
		DataExampleChar.generateRandomNumberFileUnBuffered();
		DataExampleChar.readIntegerFileInUnBuffered();
		DataExampleChar.generateRandomNumberFileBuffered();
		DataExampleChar.readIntegerFileInBuffered();
		DataExampleChar.printRunTimes();
	}

}
